# -*- coding: utf-8 -*-
"""
Created on Fri Dec 29 13:05:38 2017

@author: yxue
"""

import tkinter as tk
import getpass
import tkinter.filedialog
import os
import win32com.client
import pandas as pd


class reportGUI:
    def __init__ (self, master, path1, path2, path3):
        self.lbl = tk.Label(master, text = "\n\n Select your files: \n")
        self.lbl.pack()
        self.btn = tk.Button(master, text = "Choose template file", command = self.click1)
        self.btn.pack()
        self.btn = tk.Button(master, text = "Choose today's PnL file", command = self.click2)
        self.btn.pack()
        self.btn = tk.Button(master, text = "Choose today's VaR file", command = self.click3)
        self.btn.pack()
        
        self.path1 = "no path"
        self.path2 = "no path"
        self.path3 = "no path"
        
    def click1(self):
        user = getpass.getuser()
        file = tkinter.filedialog.askopenfilename(initialdir='C:/Users/%s' % user)
        directory = os.path.abspath(file)
        print (directory)
        self.path1 = directory
       
    def click2(self):
        user = getpass.getuser()
        file = tkinter.filedialog.askopenfilename(initialdir='C:/Users/%s' % user)
        directory = os.path.abspath(file)
        print (directory)
        self.path2 = directory
        
    def click3(self):
        user = getpass.getuser()
        file = tkinter.filedialog.askopenfilename(initialdir='C:/Users/%s' % user)
        directory = os.path.abspath(file)
        print (directory)
        self.path3 = directory

root = tk.Tk()
root.title("Daily Report")
root.minsize(300, 300)
sample = reportGUI(root, "no path", "no path", "no path")


def fill_data():
    os.chdir("H:")
    xl = win32com.client.gencache.EnsureDispatch('Excel.Application')
    xl.Visible = True
    xl.Workbooks.Open(Filename = sample.path1,ReadOnly = 0)
    ws = xl.Worksheets('Backtesting')
    ws.AutoFilterMode = False
    cp = [x[0] for x in ws.Columns(8).Value if x[0] != None]
    deli = []
    
    for i in range(len(cp)):
        if cp[i] != cp[i-1]:
            deli.append(i+1)
            
    deli = deli[1:]
    
   
    
    add = 0
    blank = []
    for i in deli:
        ws.Range('A%d'%(i+add),'AD%d'%(i+add)).Insert()
        blank.append(i+add)
        add+=1
        
        
    for i in blank:
        ws.Range('A%d'%(i+1),'AD%d'%(i+1)).Copy(ws.Range('A%d'%(i),'Z%d'%(i)))
        
    used = ws.UsedRange
    n = used.Row + used.Rows.Count - 1
    ws.Range("B2",'B%d'%n).Value = ""

    
    cp = [x[0] for x in ws.Columns(8).Value if x[0] != None]
    deli = []
    position_dic = {}
    for i in range(len(cp)):
        if cp[i] != cp[i-1]:
            deli.append(i+1)
            position_dic[cp[i]] = i+1

    deli = deli[1:]


    data = pd.read_excel(sample.path2,index_col = 0)
    names = data.index

    data_dic = {n:data.loc[n][['10-Day P&L','SIMM Pledgor','SIMM Secured']] for n in names}

    in_name = [x for x in names if x in position_dic.keys()]
    for i in in_name:
        ws.Cells(position_dic[i],2).Value = "Last"
        ws.Cells(position_dic[i],10).Value = data_dic[i].iloc[0]
        ws.Cells(position_dic[i],11).Value = data_dic[i].iloc[1]
        ws.Cells(position_dic[i],12).Value = data_dic[i].iloc[2]
        ws.Cells(position_dic[i],9).Value = entry.get()
    
    print ('Backtesting done')
    wrong_name = [x for x in names if x not in position_dic.keys()]
    if len(wrong_name) != 0:
        print ('%s is wrong'%str(wrong_name))
   
    ws2 = xl.Worksheets('Benchmarking')

    rangeObj = ws2.Range("A2:AD31")
    rangeObj.EntireRow.Insert()
    ws2.Range("A32:AD61").Copy(ws2.Range("A2:AD31"))

    
    xl2 = win32com.client.Dispatch('Excel.Application')
    xl2.Visible = True
    xl2.Workbooks.Open(Filename = sample.path3, ReadOnly = 0)
    ws1 = xl2.Worksheets(1)
    #ws1.Columns(9).EntireColumn.Delete()
    #ws1.Columns(9).EntireColumn.Delete()
    ws1.Range("B2:B31").Copy(ws2.Range("G2:G31"))
    ws1.Range("E2:L31").Copy(ws2.Range("H2:O31"))

    print ('Benchmarking done')
           
def close_window():
    root.destroy()
    
label = tk.Label(root, text = "\n\n Input your compare date: ")
label.pack()
entry = tk.Entry(root)
entry.pack()
entry.insert(0, "MM/DD/YYYY")   

label_blank = tk.Label(root, text = "\n\n")
label_blank.pack()
button_run = tk.Button(root, text = "Run", command = fill_data)
button_run.pack()
label_blank3 = tk.Label(root, text = "\n")
label_blank3.pack()
button_quit = tk.Button(root, text = "Quit", command = close_window)
button_quit.pack()
label_blank2 = tk.Label(root, text = "\n\n")
label_blank2.pack()
root.mainloop()


