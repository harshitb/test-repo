import cx_Oracle
import os
import base64
import pandas as pd


config  = {}

def initialize_config():
    config['oraUser'] = os.environ['DBUSER']
    config['oraPass'] = str(base64.b64decode((os.environ['DBPASSWD'][::-1] + '=\n').encode('ascii')).decode('ascii'))
    config['oraDB'] = os.environ['ORADB']


def display_config():
    for key in config.keys():
        print('config key : ', key, ' has value = ', config[key])


def connect_OraDB(user, pwd, db):
    print('Connecting to Oracle DB', db)
    try:
        conn = cx_Oracle.Connection(user = user, password = pwd, dsn = db)
        if conn is not None:
            print('Connected ...')
            return conn
    except Exception as e:
        print(str(e), 'DB connection failed...')
        exit()
        return None

def read_Entity():
    #initialize the config dict
    initialize_config()       
    #fetching the Entity table in dataframe
    print('Entity Table dataframe building')
    sql = 'select ENTITY_NM, ENTITY_DESC from RISK_ADM.ENTITY where ENTITY_TYPE = \'CP\''

    try:
        conn = connect_OraDB(config['oraUser'], config['oraPass'], config['oraDB'])
        if conn is not None:
            print('Connection successful')
            df = pd.read_sql(sql, conn)
            print(df.loc[:10])
    
    except Exception as e :
        print(e)

    else:
        conn.close()
        
    finally:
        print('check read_Entity function')
    
	

def read_REVAL_PnL():
    sql = 'select * from RISK_ADM.REVAL_PNL where  COB = to_date(\'20181024\', \'YYYYMMDD\')   and  DEAL_NUMBER in (9643563, 9643564)'
    print(sql)

    print('Initializing Config')
    initialize_config()

    print('display config')
    display_config()

    print('Connecting to DB')
    conn = connect_OraDB(config['oraUser'], config['oraPass'], config['oraDB'])

    try:
        c = conn.cursor()
        print('Running the sql')
        c.execute(sql)
        for x in c.fetchall():
            print(x)
            print(type(x))

    except Exception as e:
        print(str(e))

    finally:
        conn.close()

if __name__ == '__main__':
    initialize_config()
    display_config()
    
        
    
    
    
    
    
    
    
        
