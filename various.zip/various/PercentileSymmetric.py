# -*- coding: utf-8 -*-
"""
Created on Tue May  1 09:27:15 2018

@author: xiaoweiyan
"""

import numpy as np

def percentile_method(arr,percentile):
    arr = sorted(arr)

    if percentile == 0:
        return arr[0]
    index = len(arr)*percentile   
    floor = int(np.floor(index))  
    if floor == index:
        return arr[floor-1]
    cap = int(np.ceil(index))
    if (percentile < 0.5):      
        left = arr[floor-1]
        right = arr[cap-1]
        plus = (right - left)*(index - floor)
        return left+plus
    else:
        left = arr[floor]
        right = arr[cap]
        plus = (right - left)*(index - floor)
        return left+plus

import pandas
df = pandas.read_excel('H:\VaR Comparison\Data.xlsx')

arr1 = [0]*252
for i in range(0,252):
    arr1[i] = df.iloc[i,1]
percentile1 = 0.01
percentile2 = 0.99

print(percentile_method(arr1,percentile1))
print(percentile_method(arr1,percentile2))


